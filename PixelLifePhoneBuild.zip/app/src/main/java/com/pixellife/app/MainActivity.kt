package com.pixellife.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Ink = Color(0xFF292733)
private val Muted = Color(0xFF85818D)
private val Purple = Color(0xFF9A83C7)
private val Pale = Color(0xFFF6F5F8)
private val RedBg = Color(0xFFFFEEEE)
private val Red = Color(0xFFB74747)
private val GreenBg = Color(0xFFEDF7EF)
private val Green = Color(0xFF438253)

data class Quest(val id: String, val title: String, val xp: Int, val detail: String = "")
data class DayData(val done: MutableSet<String> = mutableSetOf())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PixelLifeApp(getSharedPreferences("pixel-life", MODE_PRIVATE)) }
    }
}

@Composable
fun PixelLifeApp(prefs: android.content.SharedPreferences) {
    val base = remember {
        listOf(
            Quest("study", "Study for 3 hours", 5, "Your exam quest"),
            Quest("move", "Movement / workout", 3, "Rest and recovery count too"),
            Quest("salah", "All 5 Salah", 3, "Your spiritual quest"),
            Quest("hygiene", "Skincare + hygiene", 3, "Clean, comfortable, cared for"),
            Quest("meals", "Balanced meals", 1, "Nourish yourself"),
            Quest("water", "Drink enough water", 1, "Hydration power-up"),
            Quest("phone", "No phone until 5 PM", 2, "Protect your focus"),
            Quest("sleep", "Sleep on time", 2, "Recharge for tomorrow")
        )
    }
    var custom by remember { mutableStateOf(prefs.getString("custom", "")!!.split("|").filter { it.isNotBlank() }) }
    var hobbyList by remember { mutableStateOf(prefs.getString("hobbies", "||||")!!.split("|").let { (it + listOf("", "", "", "")).take(4) }) }
    var selectedDay by remember { mutableIntStateOf(0) }
    var tab by remember { mutableStateOf("Quests") }
    var newQuest by remember { mutableStateOf("") }
    var newHobby by remember { mutableStateOf("") }
    var days by remember {
        mutableStateOf(
            (0..6).map { i ->
                val arr = JSONArray(prefs.getString("day$i", "[]"))
                DayData((0 until arr.length()).map { arr.getString(it) }.toMutableSet())
            }
        )
    }
    fun save() {
        val e = prefs.edit()
        days.forEachIndexed { i, d -> e.putString("day$i", JSONArray(d.done.toList()).toString()) }
        e.putString("custom", custom.joinToString("|"))
        e.putString("hobbies", hobbyList.joinToString("|"))
        e.apply()
    }
    val quests = base + custom.mapIndexed { i, s -> Quest("custom$i", s, 1, "Bonus quest") }
    fun score(d: DayData) = quests.filter { it.id in d.done }.sumOf { it.xp }.coerceAtMost(20)
    val total = days.sumOf { score(it) }
    val goodDays = days.count { score(it) >= 15 }
    val level = 1 + total / 100
    val today = days[selectedDay]

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Purple, onPrimary = Color.White, background = Color.White,
        surface = Color.White, onSurface = Ink
    )) {
        Scaffold(containerColor = Color.White) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("PIXEL LIFE", fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp, color = Ink)
                        Text("YOUR LITTLE LEVEL-UP ADVENTURE", fontSize = 9.sp, color = Muted, letterSpacing = 1.sp)
                    }
                    Text("LEVEL $level", color = Purple, fontWeight = FontWeight.Bold,
                        modifier = Modifier.border(1.dp, Purple, RoundedCornerShape(8.dp)).padding(9.dp))
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("TOTAL XP", "$total 🪙", Modifier.weight(1f))
                    StatCard("GOOD DAYS", "$goodDays / 7", Modifier.weight(1f))
                    StatCard("LEVEL", "$level ⭐", Modifier.weight(1f))
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Quests", "Calendar", "Stats", "Hobbies").forEach { item ->
                        val active = tab == item
                        Text(item, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = if (active) Color.White else Muted,
                            modifier = Modifier.weight(1f).background(if (active) Purple else Pale, RoundedCornerShape(9.dp))
                                .clickable { tab = item }.padding(vertical = 11.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
                Spacer(Modifier.height(12.dp))
                when (tab) {
                    "Quests" -> {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("PLAYER CHARACTER", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(if ("water" in today.done) "HYDRATED ✨" else "THIRSTY MODE", color = if ("water" in today.done) Green else Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(Modifier.fillMaxWidth().background(Pale, RoundedCornerShape(16.dp)).padding(14.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if ("water" in today.done && "hygiene" in today.done) "🧚🏻‍♀️" else if ("water" in today.done) "🙂" else "🥴", fontSize = 46.sp)
                                Text(if ("water" in today.done) "Sparkle mode!" else "Needs a water break!", fontWeight = FontWeight.Bold, color = Ink)
                                Text(if ("hygiene" in today.done) "Fresh outfit unlocked" else "Messy outfit mode", color = Muted, fontSize = 11.sp)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${listOf("MON","TUE","WED","THU","FRI","SAT","SUN")[selectedDay]} QUESTS", fontWeight = FontWeight.Bold)
                            Text("${score(today)} / 20 XP", color = Purple, fontWeight = FontWeight.Bold)
                        }
                        LinearProgressIndicator(progress = { score(today) / 20f }, modifier = Modifier.fillMaxWidth().height(7.dp), color = Purple, trackColor = Pale)
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(quests, key = { it.id }) { q ->
                                val done = q.id in today.done
                                Row(Modifier.fillMaxWidth().background(if (done) GreenBg else RedBg, RoundedCornerShape(12.dp))
                                    .clickable {
                                        val changed = days.mapIndexed { i, d ->
                                            if (i == selectedDay) DayData(d.done.toMutableSet().apply { if (done) remove(q.id) else add(q.id) }) else d
                                        }
                                        days = changed
                                        save()
                                    }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(q.title, color = if (done) Green else Red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        if (q.detail.isNotBlank()) Text(q.detail, color = Muted, fontSize = 10.sp)
                                    }
                                    Text("${q.xp} XP", color = if (done) Green else Red, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (done) "✓" else "□", color = if (done) Green else Red, fontSize = 22.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Field(newQuest, { newQuest = it }, "Add a custom quest", Modifier.weight(1f))
                            Spacer(Modifier.width(6.dp))
                            Button(onClick = {
                                if (newQuest.isNotBlank() && custom.size < 4) {
                                    custom = custom + newQuest.trim()
                                    newQuest = ""
                                    save()
                                }
                            }, enabled = newQuest.isNotBlank() && custom.size < 4, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) { Text("+") }
                        }
                        Text("Up to 4 bonus quests · 1 XP each · daily score capped at 20", fontSize = 9.sp, color = Muted)
                    }
                    "Calendar" -> {
                        Text("WEEKLY CALENDAR", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        (0..6).forEach { i ->
                            val names = listOf("MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY","SUNDAY")
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(if (selectedDay == i) Pale else Color.White, RoundedCornerShape(10.dp))
                                .clickable { selectedDay = i; tab = "Quests" }.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(names[i], fontWeight = FontWeight.Bold, color = Ink)
                                Text("${score(days[i])} / 20 XP", color = Purple, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text("Tap a day to edit its quests.", color = Muted, fontSize = 11.sp)
                    }
                    "Stats" -> {
                        Text("WEEKLY STATISTICS", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Text("XP earned each day", color = Muted, fontSize = 12.sp)
                        (0..6).forEach { i ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(listOf("M","T","W","T","F","S","S")[i], modifier = Modifier.width(22.dp), fontWeight = FontWeight.Bold)
                                Box(Modifier.weight(1f).height(12.dp).background(Pale, RoundedCornerShape(8.dp))) {
                                    Box(Modifier.fillMaxWidth(score(days[i]) / 20f).fillMaxHeight().background(Purple, RoundedCornerShape(8.dp)))
                                }
                                Text("${score(days[i])}", modifier = Modifier.width(34.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("BADGES", fontWeight = FontWeight.Bold)
                        BadgeRow("🌱", "First step", days.any { it.done.isNotEmpty() })
                        BadgeRow("⚡", "Power-up: 10 XP", days.any { score(it) >= 10 })
                        BadgeRow("👑", "Perfect day: 20 XP", days.any { score(it) == 20 })
                        BadgeRow("🏆", "Consistency: 3 good days", goodDays >= 3)
                        Spacer(Modifier.height(10.dp))
                        Text("Weekly goal: $total / 140 XP", fontWeight = FontWeight.Bold, color = Purple)
                    }
                    else -> {
                        Text("HOBBIES BOARD", fontWeight = FontWeight.Bold)
                        Text("Four slots for your favourite side quests.", color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(12.dp))
                        hobbyList.forEachIndexed { i, hobby ->
                            var draft by remember(hobby, i) { mutableStateOf(hobby) }
                            Column(Modifier.fillMaxWidth().background(Pale, RoundedCornerShape(12.dp)).padding(12.dp)) {
                                Text("SLOT ${i + 1}", fontSize = 10.sp, color = Muted, fontWeight = FontWeight.Bold)
                                Field(draft, { draft = it }, "e.g. Drawing, chess, reading")
                                Button(onClick = {
                                    hobbyList = hobbyList.toMutableList().also { it[i] = draft }.toList()
                                    save()
                                }, enabled = draft.isNotBlank()) { Text("Save hobby") }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("PIXEL LIFE · LEVEL 1 · YOUR RULES, YOUR PACE", modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = Muted, fontSize = 9.sp)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Pale, RoundedCornerShape(12.dp)).padding(10.dp)) {
        Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    Box(modifier.background(Color.White, RoundedCornerShape(8.dp)).border(1.dp, Color(0xFFE7E4EC), RoundedCornerShape(8.dp)).padding(10.dp)) {
        if (value.isEmpty()) Text(hint, color = Muted, fontSize = 12.sp)
        BasicTextField(value, onChange, textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 13.sp), singleLine = true)
    }
}

@Composable
fun BadgeRow(icon: String, label: String, unlocked: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(if (unlocked) GreenBg else Pale, RoundedCornerShape(9.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Text(label, modifier = Modifier.weight(1f), color = if (unlocked) Green else Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(if (unlocked) "UNLOCKED" else "LOCKED", color = if (unlocked) Green else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}
